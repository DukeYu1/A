import re
import json
import time
import requests
from urllib.parse import urlencode

def setCache(key, value):
    if type(value) == dict or type(value) == list:
        value = json.dumps(value, ensure_ascii=False)
    value = value.encode()
    requests.post('http://127.0.0.1:8000/cache', params={'key': key}, data=value, headers={'Content-Length': str(len(value))}, timeout=5)

def getCache(key):
    r = requests.get('http://127.0.0.1:8000/cache', params={'key': key}, timeout=5)
    value = r.text
    if value == '':
        return None
    if value.startswith('{') and value.endswith('}') or value.startswith('[') and value.endswith(']'):
        value = json.loads(value)
        if type(value) == dict:
            if not 'expires_at' in value or value['expires_at'] >= int(time.time()):
                return value
            delCache(key)
            return None
    return value

def delCache(key):
    requests.delete('http://127.0.0.1:8000/cache', params={'key': key}, timeout=5)

def getDanmuUrl(params):
    return 'http://localUrl/danmu?' + urlencode({'params': json.dumps(params, ensure_ascii=False)})

def getProxyUrl(spider, function, params):
    return 'http://localUrl/proxy?' + urlencode({'spider': spider, 'function': function, 'params': json.dumps(params, ensure_ascii=False)})

def cleanText(src):
    clean = re.sub('[\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF\U0001F1E0-\U0001F1FF]', '', src)
    return clean

def removeHtmlTags(src):
    clean = re.compile('<.*?>')
    return re.sub(clean, '', src)

def removeEmoji(src, xml=False):
    regrexPattern = re.compile(
        pattern="["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
        u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
        u"\U00002500-\U00002BEF"  # chinese char
        u"\U00002702-\U000027B0"
        u"\U00002702-\U000027B0"
        u"\U0001f926-\U0001f937"
        u"\U00010000-\U0010ffff"
        u"\u2640-\u2642"
        u"\u2600-\u2B55"
        u"\u200d"
        u"\u23cf"
        u"\u23e9"
        u"\u231a"
        u"\ufe0f"  # dingbats
        u"\u3030"
        u"\b"
        "]+",
        flags=re.UNICODE)
    content = regrexPattern.sub(r'', src)
    if xml:
        patternDict = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "\"": "&quot;",
            "\'": "&apos;"
        }
        for key in patternDict:
            content = re.sub(r'{}'.format(key), patternDict[key], content)
    return content