from live import LIVE
from huya import HUYA
from douyu import DOUYU
from douyin import DOUYIN
from youtube import YOUTUBE

SPIDERS = {
    LIVE.__name__: LIVE(),
    HUYA.__name__: HUYA(),
    DOUYU.__name__: DOUYU(),
    DOUYIN.__name__: DOUYIN(),
    YOUTUBE.__name__: YOUTUBE()
}
